<?php 

$this->assign('title', 'Home');

?>


<?= $this->element('Lms.Default/home-header')?>
<?= $this->element('Lms.Default/featured-courses')?>
<?= $this->element('Lms.Default/shorts')?>
<?= $this->element('Lms.Default/sub-section')?>
<?= $this->element('Lms.Default/find-the-best-instructor')?>
<?= $this->element('Lms.Default/all-instructors')?>
<?= $this->element('Lms.Default/testimonials')?>



