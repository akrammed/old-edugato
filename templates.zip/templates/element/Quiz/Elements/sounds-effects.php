<audio id="correct-sound" hidden>
    <source src="<?= $this->Url->build('/img/uploads/audio/success.mp3') ?>" type="audio/wav">
</audio>
<audio id="false-sound" hidden>
<source src="<?= $this->Url->build('/img/uploads/audio/false.mp3') ?>" type="audio/wav">
</audio>