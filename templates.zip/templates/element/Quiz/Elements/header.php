<div class="header">
    <div class="container-loading ">
        <input type="radio" class="radio" name="progress" value="five" id="five" checked hidden>
        <input type="radio" class="radio" name="progress" value="twentyfive" id="twentyfive" hidden>
        <input type="radio" class="radio" name="progress" value="fifty" id="fifty" hidden>
        <input type="radio" class="radio" name="progress" value="seventyfive" id="seventyfive" hidden>
        <input type="radio" class="radio" name="progress" value="onehundred" id="onehundred" hidden>

        <div class="progress">
            <div class="progress-bar"></div>
        </div>
    </div>
</div>