<svg width="41" height="41" viewBox="0 0 41 41" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_d_3_3)">
        <circle cx="24" cy="15" r="9" fill="white" />
        <circle cx="24" cy="15" r="8.5" stroke="#9AA8BC" stroke-opacity="0.2" />
    </g>
    <g filter="url(#filter1_d_3_3)">
        <circle cx="12.5" cy="26.5" r="4.5" fill="white" />
        <circle cx="12.5" cy="26.5" r="4" stroke="#9AA8BC" stroke-opacity="0.2" />
    </g>
    <defs>
        <filter id="filter0_d_3_3" x="7" y="0" width="34" height="34" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                result="hardAlpha" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_3_3" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_3_3" result="shape" />
        </filter>
        <filter id="filter1_d_3_3" x="0" y="16" width="25" height="25" filterUnits="userSpaceOnUse"
            color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                result="hardAlpha" />
            <feOffset dy="2" />
            <feGaussianBlur stdDeviation="4" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.04 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_3_3" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_3_3" result="shape" />
        </filter>
    </defs>
</svg>