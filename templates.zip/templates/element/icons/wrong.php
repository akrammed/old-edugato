<svg class="icon-alert" width="72" height="72" viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_104_13011)">
        <path
            d="M23.3465 9H48.6507C57.495 9 63 15.2436 63 24.0791V47.9208C63 56.7564 57.495 63 48.6477 63H23.3465C14.5021 63 9 56.7564 9 47.9208V24.0791C9 15.2436 14.5284 9 23.3465 9Z"
            fill="#F6F8FB" stroke="#B1000F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M42.9852 28.9803L28.9979 42.9678M43.0029 42.9855L28.9922 28.9746" stroke="#B1000F" stroke-width="1.5"
            stroke-linecap="round" stroke-linejoin="round" />
    </g>
    <defs>
        <clipPath id="clip0_104_13011">
            <rect width="72" height="72" fill="white" />
        </clipPath>
    </defs>
</svg>