<svg width="18" height="18" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M5.33366 10.6667C5.33366 10.6667 0.666992 7.90404 0.666992 6.00004C0.666992 4.09671 5.33366 1.33337 5.33366 1.33337"
        stroke="#9AA8BC" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" />
</svg>