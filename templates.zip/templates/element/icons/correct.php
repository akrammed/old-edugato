<svg class="icon-alert" width="72" height="72" viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M23.3465 9H48.6507C57.495 9 63 15.2436 63 24.0791V47.9208C63 56.7564 57.495 63 48.6477 63H23.3465C14.5021 63 9 56.7564 9 47.9208V24.0791C9 15.2436 14.5284 9 23.3465 9Z"
        fill="#F6F8FB" stroke="#016A1C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M25.6055 36.0009L32.535 42.9273L46.3881 29.0742" stroke="#016A1C" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
</svg>