<svg style="margin-left: -9%;" width="30" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.5601 21.0402C9.86902 20.9343 9.20739 20.7432 8.58398 20.4932" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.12749 18.9967C5.69621 18.6419 5.29237 18.239 4.92773 17.7881" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3.48912 15.3026C3.26857 14.7272 3.09606 14.1127 3 13.4795" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3.54695 8.63379C3.28818 9.25719 3.10586 9.91981 3 10.601" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.24374 4.96875C5.80265 5.33338 5.38999 5.73624 5.03516 6.16851" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10.5614 3.04004C9.92824 3.1361 9.31366 3.29881 8.73828 3.52916" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.3969 3.58699C14.7833 3.32822 14.1207 3.1459 13.4395 3.04004" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M19.0611 6.28378C18.7063 5.84269 18.3034 5.43003 17.8613 5.0752" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M21.0008 10.6005C20.9048 9.96734 20.7323 9.35276 20.5117 8.76758" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M21.0001 13.4795C20.8942 14.1705 20.7031 14.8223 20.4531 15.4467" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M18.9566 17.9023C18.6018 18.3434 18.1989 18.7463 17.748 19.1021" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.2626 20.541C14.6872 20.7713 14.0727 20.934 13.4395 21.0399" stroke="#9AA8BC" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
</svg>