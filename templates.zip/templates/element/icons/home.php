<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.56543 13.4463H12.4112" stroke="#1A212B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M2 11.0371C2 6.53235 2.51241 6.84675 5.27061 4.39475C6.47737 3.46355 8.35509 1.66675 9.97662 1.66675C11.5973 1.66675 13.5126 3.45475 14.7302 4.39475C17.4884 6.84675 18 6.53235 18 11.0371C18 17.6667 16.3651 17.6667 9.99999 17.6667C3.63489 17.6667 2 17.6667 2 11.0371Z" stroke="#1A212B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
