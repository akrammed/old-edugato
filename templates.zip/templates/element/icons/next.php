<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd"
        d="M12 21.25C18.937 21.25 21.25 18.937 21.25 12C21.25 5.063 18.937 2.75 12 2.75C5.063 2.75 2.75 5.063 2.75 12C2.75 18.937 5.063 21.25 12 21.25Z"
        stroke="#5C17E5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M10.5581 15.4713C10.5581 15.4713 14.0441 13.0793 14.0441 11.9993C14.0441 10.9193 10.5581 8.5293 10.5581 8.5293"
        stroke="#5C17E5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg>