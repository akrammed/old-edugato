sy

<?= $this->element('Lms.Default/slider-home')?>
<?= $this->element('Lms.Default/featured-courses')?>







<!-- <div class="home-sections container">
    <div class="row">
        <div class="col-12">
            <a href="/login">
                <img src="img/default/1/default_images/banners/become_instructor_banner.png"
                    class="img-cover rounded-sm" alt="Home - Join as instructor">
            </a>
        </div>
    </div>
</div> -->




<?= $this->element('Lms.Default/become-an-instructor')?>
<?= $this->element('Lms.Default/find-the-best-instructor')?>
<?= $this->element('Lms.Default/all-instructors')?>

<!-- <div class="home-sections container">
    <div class="row">
        <div class="col-6">
            <a href="/certificate_validation">
                <img src="img/default/1/default_images/banners/validate_certificates_banner.png"
                    class="img-cover rounded-sm" alt="Certificate validation - Home">
            </a>
        </div>
        <div class="col-6">
            <a href="/instructors">
                <img src="img/default/1/default_images/banners/reserve_a_meeting.png" class="img-cover rounded-sm"
                    alt="Reserve a meeting - Home">
            </a>
        </div>
    </div>
</div> -->

<?= $this->element('Lms.Default/testimonials')?>
