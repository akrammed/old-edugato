<?php 

$this->assign('title', 'Contact Us');

?>
<?= $this->element('Lms.Default/contact')?>
