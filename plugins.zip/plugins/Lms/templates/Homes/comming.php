
    

    <div id="panel_app">

        <section class="mt-35">
           
    
            
                <div class="no-result default-no-result mt-50 d-flex align-items-center justify-content-center flex-column">
        <div class="no-result-logo">
            <?= $this->Html->image('comment.png') ?>
        </div>
        <div class="d-flex align-items-center flex-column mt-30 text-center">
            <h2 class="text-dark-blue">Comming soon</h2>
            <p class="mt-1 text-center text-gray font-weight-500">This service will be available soon</p>
                </div>
    </div>
    
            
        </section>

    </div>