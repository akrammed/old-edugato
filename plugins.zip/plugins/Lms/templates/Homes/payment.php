<?php 
$this->assign('title', 'Payment');
?>
<?= $this->element('Lms.Default/payment-section',['course'=>$course])?>
