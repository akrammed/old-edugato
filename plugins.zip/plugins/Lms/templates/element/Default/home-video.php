
<section class="home-sections home-sections-swiper position-relative">
        <div class="home-video-mask"></div>
        <div class="container home-video-container d-flex flex-column align-items-center justify-content-center position-relative"
            style="background-image: url('img/default/1/default_images/home_video_section.png')">
            <a href="/classes"
                class="home-video-play-button d-flex align-items-center justify-content-center position-relative">
                <i data-feather="play" width="36" height="36" class=""></i>
            </a>

            <div class="mt-50 pt-10 text-center">
                <h2 class="home-video-title">Start learning anywhere, anytime...</h2>
                <p class="home-video-hint mt-10">Use Rocket LMS to access high-quality education materials without any
                    limitations in the easiest way.</p>
            </div>
        </div>
    </section>

