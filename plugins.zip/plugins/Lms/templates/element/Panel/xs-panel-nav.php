<div class="xs-panel-nav d-flex d-lg-none justify-content-between py-5 px-15">
            <div class="user-info d-flex align-items-center justify-content-between">
                <div class="user-avatar bg-gray200">
                    <img src="/store/867/avatar/617a502cf268a.png" class="img-cover" alt="Light Moon">
                </div>

                <div class="user-name ml-15">
                    <h3 class="font-16 font-weight-bold">Light Moon</h3>
                </div>
            </div>

            <button class="sidebar-toggler btn-transparent d-flex flex-column-reverse justify-content-center align-items-center p-5 rounded-sm sidebarNavToggle" type="button">
                <span>Menu</span>
                <i data-feather="menu" width="16" height="16"></i>
            </button>
    </div>